"""Singleton dock panel for NeuroCad.

Contains get_panel_dock() lazy singleton and CopilotPanel QDockWidget.
"""

from ..config.config import load as load_config
from ..core.active_document import get_active_document
from ..core.audit import init_audit_log, audit_log
from ..core.debug import log_error, log_info, log_warn
from ..core.history import History
from ..core.worker import LLMWorker
from ..llm.registry import load_adapter
from .compat import Qt, QtCore, QtWidgets
from .widgets import MessageBubble, StatusDot


class AdaptivePlainTextEdit(QtWidgets.QPlainTextEdit):
    """Multi-line input with adaptive height and Enter-to-submit, Shift+Enter for newline."""

    submitted = QtCore.Signal()
    _FIXED_OVERHEAD = 61  # sum of container margins, spacing, divider, toolbar height

    def __init__(self, parent=None, scroll_area=None, container=None):
        super().__init__(parent)
        self.setPlaceholderText("Type your CAD request...")
        self._scroll_area_ref = scroll_area
        self._container_ref = container
        self.setMaximumHeight(self._get_max_height())
        self.setMinimumHeight(self.fontMetrics().lineSpacing() + 10)
        self.textChanged.connect(self._adjust_height)

    def _get_max_height(self):
        """Return maximum allowed height based on container or scroll area height."""
        # First, try container-based limit (container max height minus fixed overhead)
        if self._container_ref is not None:
            container_max = self._container_ref.maximumHeight()
            # Qt default maximum is 16777215, treat as unlimited
            if container_max < 16777215:
                # Subtract fixed overhead (margins, spacing, divider, toolbar)
                available = container_max - self._FIXED_OVERHEAD
                if available > self.minimumHeight():
                    return max(available, self.minimumHeight())
        # Fallback to scroll area half (previous behavior)
        if self._scroll_area_ref is not None and self._scroll_area_ref.height() > 0:
            # half of scroll area height, but not less than minimum
            return max(self._scroll_area_ref.height() // 2, self.minimumHeight())
        # fallback
        return 200

    def _adjust_height(self):
        doc = self.document()
        line_count = doc.lineCount()
        font_height = self.fontMetrics().lineSpacing()
        margins = self.contentsMargins()
        total_height = font_height * line_count + margins.top() + margins.bottom() + 10
        max_height = self._get_max_height()
        new_height = min(max_height, max(total_height, self.minimumHeight()))
        self.setMaximumHeight(new_height)
        self.updateGeometry()

    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Return and not event.modifiers() & QtCore.Qt.ShiftModifier:
            self.submitted.emit()
            event.accept()
            return
        super().keyPressEvent(event)


# Global singleton dock widget
_panel_dock = None


def get_panel_dock(create: bool = True):
    """Return the global NeuroCad dock widget, creating it if needed.

    If create=False and the dock does not exist, returns None.
    """
    global _panel_dock
    if _panel_dock is not None:
        return _panel_dock
    if not create:
        return None

    # Need FreeCAD's main window
    try:
        import FreeCADGui  # type: ignore

        mw = FreeCADGui.getMainWindow()
    except ImportError:
        mw = None

    if mw is None:
        return None

    _panel_dock = CopilotPanel(mw)
    if hasattr(mw, "addDockWidget"):
        mw.addDockWidget(Qt.RightDockWidgetArea, _panel_dock)  # type: ignore[attr-defined]
    return _panel_dock


class CopilotPanel(QtWidgets.QDockWidget):
    """Main chat panel dock widget."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("NeuroCadDockWidget")
        self.setWindowTitle("NeuroCAD")
        self._worker = None
        self._history = History()
        self._adapter = None
        self._config = {}
        self._request_watchdog = None
        self._last_new_objects = []
        self._scroll_pending = False
        self._adapter_error = None

        self._build_ui()
        self._connect_signals()
        self._init_adapter()

    def _init_adapter(self):
        """Load adapter from config (falls back to mock if no key)."""
        try:
            config = load_config()
            self._config = config
            # Initialize audit logging based on config
            init_audit_log(config)
            log_info(
                "panel.init_adapter",
                "loading adapter",
                provider=config.get("provider"),
                model=config.get("model"),
                base_url=config.get("base_url"),
                timeout=config.get("timeout"),
            )
            self._adapter = load_adapter(config)
            log_info(
                "panel.init_adapter",
                "adapter loaded",
                adapter_type=type(self._adapter).__name__,
            )
            # Clear any previous error
            self._adapter_error = None
            self._update_status_for_adapter()
        except Exception as e:
            # If no API key is configured, we'll keep adapter as None
            # and show an error when user tries to submit.
            if not self._config:
                self._config = load_config()
            self._adapter = None
            self._adapter_error = e
            log_warn("panel.init_adapter", "adapter unavailable", error=e)
            # Audit log the failure
            audit_log(
                "adapter_init_failure",
                {
                    "provider": self._config.get("provider"),
                    "error": str(e),
                },
            )
            self._update_status_for_adapter()

    def _update_status_for_adapter(self):
        """Update status label based on adapter state."""
        if self._adapter is not None:
            self._status_label.setText("Ready")
            self._status_label.setStyleSheet("color: #666; font-style: italic;")
            self._status_label.setToolTip("")
        else:
            # No adapter, show error if any
            if self._adapter_error is None:
                self._status_label.setText("No LLM adapter configured")
                self._status_label.setStyleSheet("color: #666; font-style: italic;")
                self._status_label.setToolTip("")
            else:
                # Determine user-friendly message
                err = self._adapter_error
                if isinstance(err, ValueError):
                    err_text = str(err)
                    # Differentiate missing key vs keyring unavailable
                    if "install the `keyring` package" in err_text:
                        msg = "Secure storage unavailable"
                    elif "No API key found" in err_text or "No API key found for provider" in err_text:
                        msg = "Missing API key"
                    elif "keyring" in err_text.lower():
                        msg = "Secure storage unavailable"
                    elif "Unknown provider" in err_text:
                        msg = f"Unknown provider: {err_text.split(':')[-1].strip()}"
                    else:
                        msg = f"Configuration error: {err_text[:60]}"
                else:
                    # Other exceptions (e.g., adapter init failure)
                    msg = f"Adapter failed: {type(err).__name__}"
                self._status_label.setText(f"Error: {msg}")
                self._status_label.setStyleSheet("color: #dc2626; font-style: italic;")
                self._status_label.setToolTip(str(err))

    def set_adapter(self, adapter):
        """Set adapter directly (e.g., from Use once session)."""
        self._adapter = adapter
        if adapter is not None:
            self._adapter_error = None
            if hasattr(adapter, "timeout"):
                self._config["timeout"] = float(adapter.timeout)
            from ..core.debug import log_info

            log_info(
                "panel.set_adapter",
                "adapter updated",
                adapter_type=type(adapter).__name__,
            )
        else:
            self._adapter_error = None
            from ..core.debug import log_warn

            log_warn("panel.set_adapter", "adapter cleared")
        self._update_status_for_adapter()

    def _build_ui(self):
        """Create UI elements."""
        central = QtWidgets.QWidget()
        self.setWidget(central)
        layout = QtWidgets.QVBoxLayout(central)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        # Chat area (scrollable)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll_content = QtWidgets.QWidget()
        scroll_layout = QtWidgets.QVBoxLayout(scroll_content)
        scroll_layout.setAlignment(Qt.AlignTop)
        scroll.setWidget(scroll_content)
        self._scroll_area = scroll
        self._scroll_layout = scroll_layout
        self._scroll_content = scroll_content

        # Input elements
        self._input = AdaptivePlainTextEdit(scroll_area=self._scroll_area)
        # placeholder already set in class
        self._send_btn = QtWidgets.QPushButton("→")
        self._snapshot_btn = QtWidgets.QPushButton("Snapshot")
        self._export_btn = QtWidgets.QPushButton("Export")
        # Style secondary buttons (Snapshot, Export)
        self._snapshot_btn.setFixedHeight(24)
        self._export_btn.setFixedHeight(24)
        secondary_style = """
            QPushButton {
                background: #f9fafb;
                color: #6b7280;
                border: 1px solid #d1d5db;
                border-radius: 10px;
                padding: 3px 10px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #e8e8e8;
            }
            QPushButton:disabled {
                background-color: #f0f0f0;
                color: #aaa;
            }
        """
        self._snapshot_btn.setStyleSheet(secondary_style)
        self._export_btn.setStyleSheet(secondary_style)
        # Style send button as round blue 30x30
        self._send_btn.setFixedSize(30, 30)
        self._send_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196f3;
                border: none;
                border-radius: 15px;
                color: white;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976d2;
            }
            QPushButton:disabled {
                background-color: #b0bec5;
            }
        """)

        self._request_watchdog = QtCore.QTimer(self)
        self._request_watchdog.setSingleShot(True)
        self._request_watchdog.timeout.connect(self._on_request_timeout)

        # Status dot in title bar
        self._status_dot = StatusDot()
        title_widget = QtWidgets.QWidget()
        title_layout = QtWidgets.QHBoxLayout(title_widget)
        title_layout.setContentsMargins(0, 0, 0, 0)
        title_layout.addWidget(QtWidgets.QLabel("NeuroCAD"))
        title_layout.addStretch()
        # Status text label (replaces bottom status label)
        self._status_label = QtWidgets.QLabel("Ready")
        self._status_label.setStyleSheet("color: #666; font-style: italic;")
        title_layout.addWidget(self._status_label)
        title_layout.addSpacing(6)  # small gap between text and dot
        title_layout.addWidget(self._status_dot)
        self.setTitleBarWidget(title_widget)

        # Assemble
        layout.addWidget(scroll)

        # Unified Claude-style input container
        self._input_box = QtWidgets.QFrame()
        self._input_box.setStyleSheet("""
            QFrame {
                background: white;
                border: 1px solid #d1d5db;
                border-radius: 12px;
            }
        """)
        input_box_layout = QtWidgets.QVBoxLayout(self._input_box)
        input_box_layout.setContentsMargins(12, 12, 12, 12)
        input_box_layout.setSpacing(6)

        # Input row (just line edit)
        input_row = QtWidgets.QHBoxLayout()
        input_row.addWidget(self._input, 1)
        input_box_layout.addLayout(input_row)

        # Divider
        divider = QtWidgets.QFrame()
        divider.setFrameShape(QtWidgets.QFrame.HLine)
        divider.setStyleSheet("color: #e0e0e0;")
        divider.setFixedHeight(1)
        input_box_layout.addWidget(divider)

        # Toolbar row with compact secondary buttons and round send button
        toolbar_row = QtWidgets.QHBoxLayout()
        toolbar_row.addWidget(self._snapshot_btn)
        toolbar_row.addWidget(self._export_btn)
        toolbar_row.addStretch()
        toolbar_row.addWidget(self._send_btn)
        input_box_layout.addLayout(toolbar_row)
        # Stretch factors: input row expands, divider and toolbar stay fixed
        input_box_layout.setStretch(0, 1)  # input row
        input_box_layout.setStretch(1, 0)  # divider
        input_box_layout.setStretch(2, 0)  # toolbar row

        layout.addWidget(self._input_box)

        # Give scroll area all extra vertical space
        layout.setStretch(0, 1)  # scroll area
        layout.setStretch(1, 0)  # input container

        # Set container reference for adaptive height
        self._input._container_ref = self._input_box

        # Minimum height: sum of internal elements and margins
        input_min_height = self._input.minimumHeight()
        container_min_height = input_min_height + self._input._FIXED_OVERHEAD
        self._input_box.setMinimumHeight(container_min_height)

        # Initial max height limit (half of panel height)
        self._update_container_max_height()

    def _llm_timeout_ms(self) -> int:
        """Return configured LLM timeout in milliseconds for the UI watchdog."""
        timeout_s = float(self._config.get("timeout", 180.0))
        return max(1000, int(timeout_s * 1000))

    def _connect_signals(self):
        """Connect UI signals."""
        self._send_btn.clicked.connect(self._on_btn_clicked)
        self._snapshot_btn.clicked.connect(self._on_snapshot_requested)
        self._export_btn.clicked.connect(self._on_export_requested)
        self._input.submitted.connect(self._on_submit)

    def _add_message(self, role: str, text: str):
        """Append a message bubble to the chat area."""
        if role == "user":
            # Create row-container: QWidget with horizontal layout
            container = QtWidgets.QWidget()
            row_layout = QtWidgets.QHBoxLayout(container)
            row_layout.addStretch()
            bubble = MessageBubble(role, text)
            row_layout.addWidget(bubble)
            row_layout.setContentsMargins(0, 0, 0, 0)
            # Set maximum width relative to scroll viewport
            self._update_user_bubble_width(bubble)
            self._scroll_layout.addWidget(container)
        else:
            bubble = MessageBubble(role, text)
            self._scroll_layout.addWidget(bubble, alignment=Qt.AlignLeft)  # type: ignore[attr-defined]
        # Scroll to bottom
        self._queue_scroll_to_bottom()

    def _update_user_bubble_width(self, bubble):
        """Set maximum width of user bubble based on scroll viewport width."""
        viewport_width = self._scroll_area.viewport().width()
        max_width = int(viewport_width * 0.8)  # 80% of viewport
        bubble.setMaximumWidth(max_width)

    def _queue_scroll_to_bottom(self):
        """Schedule a scroll to bottom if not already pending."""
        if self._scroll_pending:
            return
        self._scroll_pending = True
        QtCore.QTimer.singleShot(0, self._scroll_to_bottom)

    def _scroll_to_bottom(self):
        """Scroll chat area to the bottom."""
        self._scroll_pending = False
        scrollbar = self._scroll_area.verticalScrollBar()
        if scrollbar is not None:
            scrollbar.setValue(scrollbar.maximum())

    def _set_busy(self, busy: bool):
        """Toggle between send mode (→) and stop mode (■)."""
        self._input.setEnabled(not busy)
        self._snapshot_btn.setEnabled(not busy)
        self._export_btn.setEnabled(not busy)
        if busy:
            # Transform send button into stop button (always enabled so user can cancel)
            self._send_btn.setText("■")
            self._send_btn.setToolTip("Stop")
            self._send_btn.setStyleSheet("""
                QPushButton {
                    background-color: #ef4444;
                    border: none;
                    border-radius: 15px;
                    color: white;
                    font-weight: bold;
                }
                QPushButton:hover { background-color: #dc2626; }
            """)
            self._send_btn.setEnabled(True)
            self._status_dot.set_state("thinking")
            self._status_label.setText("Thinking...")
        else:
            # Restore send button
            self._send_btn.setText("→")
            self._send_btn.setToolTip("")
            self._send_btn.setStyleSheet("""
                QPushButton {
                    background-color: #2196f3;
                    border: none;
                    border-radius: 15px;
                    color: white;
                    font-weight: bold;
                }
                QPushButton:hover { background-color: #1976d2; }
                QPushButton:disabled { background-color: #b0bec5; }
            """)
            self._send_btn.setEnabled(True)
            self._status_dot.set_state("idle")
            self._status_label.setText("Ready")

    def _on_btn_clicked(self):
        """Route send/stop button click based on current state."""
        if self._worker is not None and self._worker.is_running():
            self._on_stop()
        else:
            self._on_submit()

    def _on_stop(self):
        """Cancel the running request immediately."""
        log_info("panel.stop", "user requested stop")
        if self._request_watchdog is not None:
            self._request_watchdog.stop()
        if self._worker is not None:
            self._worker.cancel()
            self._worker = None
        self._set_busy(False)
        self._add_message("feedback", "Cancelled")
        if hasattr(self, "_current_assistant_bubble"):
            del self._current_assistant_bubble

    def _on_submit(self):
        """Handle Send button or Enter press."""
        text = self._input.toPlainText().strip()
        if not text:
            return
        log_info("panel.submit", "received user request", text=text)
        doc = get_active_document()
        if doc is None:
            log_warn("panel.submit", "blocked: no active document")
            self._add_message("feedback", "No active document.")
            return
        if self._adapter is None:
            log_warn("panel.submit", "blocked: adapter is not configured", error=self._adapter_error)
            # Determine user-friendly error message
            if self._adapter_error is None:
                msg = "LLM adapter not configured. Set API key in Settings."
            else:
                err = self._adapter_error
                if isinstance(err, ValueError):
                    err_text = str(err)
                    # Differentiate missing key vs keyring unavailable
                    if "install the `keyring` package" in err_text:
                        msg = "Secure storage unavailable. Install keyring package or set environment variable."
                    elif "No API key found" in err_text or "No API key found for provider" in err_text:
                        msg = "Missing API key. Set API key in Settings or environment variable."
                    elif "keyring" in err_text.lower():
                        msg = "Secure storage unavailable. Install keyring package or set environment variable."
                    elif "Unknown provider" in err_text:
                        provider = err_text.split(':')[-1].strip()
                        msg = f"Unknown provider '{provider}'. Check Settings."
                    else:
                        msg = f"Configuration error: {err_text[:80]}"
                else:
                    msg = f"Adapter initialization failed: {type(err).__name__}"
            self._add_message("feedback", msg)
            return
        if self._worker is not None and self._worker.is_running():
            # Already running, ignore
            log_warn("panel.submit", "ignored: worker already running")
            return

        self._add_message("user", text)
        self._input.clear()
        self._set_busy(True)
        log_info(
            "panel.submit",
            "starting worker",
            document=getattr(doc, "Name", None),
            adapter_type=type(self._adapter).__name__,
        )

        self._worker = LLMWorker(
            on_chunk=self._on_chunk,
            on_attempt=self._on_attempt,
            on_status=self._on_status,
            on_exec_needed=self._on_exec_needed,
            on_done=self._on_worker_done,
            on_error=self._on_worker_error,
        )
        self._worker.start(text, doc, self._adapter, self._history)
        self._request_watchdog.start(self._llm_timeout_ms())

    def _on_chunk(self, chunk: str):
        """Append a chunk of LLM response to the assistant message."""
        log_info("panel.chunk", "received assistant output", chars=len(chunk), preview=chunk[:160])
        # For simplicity, we'll just add a new assistant message on first chunk
        # and append to it on subsequent chunks.
        # This can be improved with a proper streaming UI in Sprint 3.
        if not hasattr(self, "_current_assistant_bubble"):
            bubble = MessageBubble("assistant", chunk)
            self._scroll_layout.addWidget(bubble)
            self._current_assistant_bubble = bubble
        else:
            self._current_assistant_bubble.append_text(chunk)
        QtCore.QTimer.singleShot(0, self._scroll_to_bottom)

    def _on_attempt(self, n: int, mx: int):
        """Update status dot with attempt progress."""
        log_info("panel.attempt", "agent attempt", attempt=n, max_attempts=mx)
        self._status_dot.set_state("thinking")
        # Update status label
        self._status_label.setText(f"Attempt {n} of {mx}")
        if n > 1:
            self._add_message("feedback", "Retrying")

    def _on_status(self, msg: str):
        """Log pipeline status internally; show compact user-facing statuses."""
        log_info("panel.status", "pipeline status", msg=msg)
        # Map internal status messages to compact user-facing bubbles
        if "sending request to LLM" in msg:
            self._add_message("feedback", "Request sent")
            self._status_label.setText("Request sent")
        elif "execution failed:" in msg:
            # Determine if it's unsupported operation
            if "Unsupported FreeCAD API used" in msg:
                self._add_message("feedback", "Unsupported operation")
                self._status_label.setText("Unsupported operation")
            else:
                self._add_message("feedback", "Execution failed")
                self._status_label.setText("Execution failed")
        elif "timed out" in msg.lower():
            self._add_message("feedback", "Timed out")
            self._status_label.setText("Timed out")
        else:
            # Generic status update (keep existing label)
            pass

    def _on_exec_needed(self, code: str, attempt: int) -> None:
        """Execute code in the main thread and hand the result back to the worker."""
        from ..core.agent import _execute_with_rollback

        log_info("panel.exec", "execution requested", attempt=attempt, code_preview=code[:200])
        doc = get_active_document()
        result_data = {"ok": False, "new_objects": [], "error": "No active document"}
        if doc is None:
            log_warn("panel.exec", "no active document during exec handoff")
            if self._worker is not None:
                self._worker.receive_exec_result(result_data)
            return

        result = _execute_with_rollback(code, doc)
        result_data = {
            "ok": result.ok,
            "new_objects": result.new_objects,
            "error": result.error,
        }
        log_info(
            "panel.exec",
            "execution finished",
            ok=result.ok,
            new_objects=result.new_objects,
            error=result.error,
        )
        if self._worker is not None:
            self._worker.receive_exec_result(result_data)

    def _on_worker_done(self, result):
        """Handle completion of the worker."""
        if self._request_watchdog is not None:
            self._request_watchdog.stop()
        log_info(
            "panel.done",
            "worker finished",
            ok=result.ok,
            attempts=result.attempts,
            error=result.error,
            new_objects=result.new_objects,
        )
        self._worker = None
        self._last_new_objects = result.new_objects if result.ok else []
        self._set_busy(False)
        if not result.ok:
            self._add_message(
                "feedback",
                f"Failed after {result.attempts} attempts: {result.error}",
            )
        else:
            self._add_message("feedback", f"Success! Created {len(result.new_objects)} object(s).")
        # Clear current assistant bubble
        if hasattr(self, "_current_assistant_bubble"):
            del self._current_assistant_bubble

    def _on_worker_error(self, msg: str):
        """Handle worker error."""
        if self._request_watchdog is not None:
            self._request_watchdog.stop()
        log_error("panel.error", "worker error", error=msg)
        self._worker = None
        self._set_busy(False)
        self._add_message("feedback", f"Worker error: {msg}")

    def _on_request_timeout(self):
        """Release the UI if a request appears stuck for too long."""
        if self._worker is None or not self._worker.is_running():
            return
        log_error("panel.timeout", "request watchdog fired", timeout_ms=self._llm_timeout_ms())
        self._worker.cancel()
        self._worker = None
        self._set_busy(False)
        self._add_message("feedback", "Timed out")

    def _on_export_requested(self):
        """Handle Export button click."""
        from pathlib import Path

        from ..core.active_document import get_active_document
        from ..core.exporter import ExportError, export_last_successful
        from .compat import QtWidgets

        doc = get_active_document()
        if doc is None:
            log_warn("panel.export", "blocked: no active document")
            self._add_message("feedback", "No active document.")
            return

        if not self._last_new_objects:
            log_warn("panel.export", "no objects to export")
            self._add_message("feedback", "No objects created yet.")
            return

        # File dialog
        file_filter = "STEP files (*.step *.stp);;STL files (*.stl)"
        file_path, selected_filter = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Export Geometry",
            "",
            file_filter,
        )
        if not file_path:
            return

        # Determine format from filter
        if "STEP" in selected_filter:
            fmt = "step"
            if not file_path.lower().endswith((".step", ".stp")):
                file_path += ".step"
        else:
            fmt = "stl"
            if not file_path.lower().endswith(".stl"):
                file_path += ".stl"

        try:
            export_last_successful(doc, Path(file_path), fmt, self._last_new_objects)
        except ExportError as e:
            log_error("panel.export", "export failed", error=str(e))
            self._add_message("feedback", f"Export failed: {e}")
            return
        except Exception as e:
            log_error("panel.export", "unexpected export error", error=e)
            self._add_message("feedback", f"Export error: {e}")
            return

        filename = Path(file_path).name
        log_info("panel.export", "export succeeded", path=file_path, format=fmt)
        self._add_message(
            "feedback",
            f"Exported {len(self._last_new_objects)} object(s) to {filename}",
        )

    def _on_snapshot_requested(self):
        """Show Snapshot button handler."""
        from ..core import context
        from ..core.active_document import get_active_document

        doc = get_active_document()
        if doc is None:
            log_warn("panel.snapshot", "blocked: no active document")
            self._add_message("feedback", "No active document.")
            return

        try:
            snap = context.capture(doc)
            prompt_str = context.to_prompt_str(snap, max_chars=8000)
            log_info(
                "panel.snapshot",
                "snapshot created",
                document=getattr(doc, "Name", None),
                chars=len(prompt_str),
            )
            self._add_message("assistant", f"Snapshot of {doc.Name}:\n{prompt_str}")
        except Exception as e:
            log_error("panel.snapshot", "snapshot failed", error=e)
            self._add_message("feedback", f"Snapshot failed: {e}")

    def _update_container_max_height(self):
        """Set container max height to half of panel height, respecting minimum."""
        panel_height = self.height()
        max_h = max(panel_height // 2, self._input_box.minimumHeight())
        self._input_box.setMaximumHeight(max_h)
        # Trigger input height recomputation
        if hasattr(self._input, "_adjust_height"):
            self._input._adjust_height()

    def resizeEvent(self, event):
        """Update container max height when panel is resized."""
        super().resizeEvent(event)
        self._update_container_max_height()

    def showEvent(self, event):
        """Ensure the dock is raised when shown."""
        super().showEvent(event)
        self.raise_()
