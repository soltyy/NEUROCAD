print("[NeuroCad] InitGui loaded")
try:
    import FreeCADGui

    from neurocad.app.workbench import CadCopilotWorkbench
except ImportError:
    FreeCADGui = None

if FreeCADGui is not None:
    try:
        # Check if already registered (idempotent)
        workbenches = FreeCADGui.listWorkbenches()
        if "CadCopilotWorkbench" in workbenches:
            print("[NeuroCad] Workbench already registered, skipping.")
        else:
            FreeCADGui.addWorkbench(CadCopilotWorkbench)
            print("[NeuroCad] Workbench registered successfully.")
    except Exception:
        # listWorkbenches may fail in some contexts; treat as not registered
        try:
            FreeCADGui.addWorkbench(CadCopilotWorkbench)
            print("[NeuroCad] Workbench registered (listWorkbenches failed).")
        except Exception as e2:
            print(f"[NeuroCad] ERROR: Failed to register workbench: {e2}")
else:
    print("[NeuroCad] FreeCADGui not available; workbench registration skipped.")
